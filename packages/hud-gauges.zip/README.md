# HUD Gauges

Enable the overlay from the HUD Gauges menu for the current iDrive session.
A compatible factory HUD and reference handle layout are required. Native NBT-AAD
and CarPlay Advanced with its HUD hook prevent the overlay from starting.

BoostDeck shares RPM and available boost on HSFZ. ShiftDeck shares RPM.
The HUD pauses while LaunchDeck owns the diagnostic link. Factory navigation
keeps priority.

See the project compatibility guide and the bundled NBT-AAD licence and notice.

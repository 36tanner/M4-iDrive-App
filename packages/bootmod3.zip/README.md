# iDrive 6 optional controls

These are optional builds for the NBT Evo QNX 6.5 ARM plugin ABI. Bootmod3 Suite is in beta. xDrive Control is experimental. Test each app separately on the intended car. Existing temporary SSH, a known compatible app framework, a functioning diagnostic gateway, and available connector IDs are required. The plugin folders are Bootmod3Suite (111) and XDriveControl (112). Install the chosen folder under /var/opt/hmi/data/ID5/Plugins, give the -qnx worker execute permission, then restart iDrive while parked. Start with a parked test.

## Bootmod3 Suite

Maps 1–4 are available on the main screen. OPTIONS opens Exhaust flap, Active Sound and Burbles. Each request starts with the upstream CustomROM marker lookup at 0x807FFE50. A unique known ROM is required. A different marker address or an unknown ROM disables commands. Maps and the three burble presets (4, 8, 12) use bounded profile-specific memory writes with readback. Exhaust and Active Sound report DME acknowledgement. The tune and hardware determine which requests work. Map switching, Exhaust Flap and Active Sound can fall back to MOST. Burble presets require HSFZ.

[Bootmod3 protocol and profiles](https://github.com/cauliflowermossgrape/idrive7-apps/tree/8d860de/apps/live_adjustments)

## Package update

The main screen reads the active map when opened and after each map selection. The worker tries the fixed direct marker read when the dynamic DID is unsupported.

Install the selected app folders under /var/opt/hmi/data/ID5/Plugins on the HMI node. Verify compatibility and set executable permissions on the -qnx worker before a parked restart. A verified IPv4 address in /var/opt/hmi/data/ID5/gateway-ip.txt overrides per-app settings. Setup instructions are in the repository AgentReadMe.

# BEAMer for iDrive 6

Front, Rear, Both, and Insane run in Park at zero speed. Tested on an F3x car. Other Fxx cars may work if they have the supported lighting module. Gxx has not been tested. Requires a 1280 x 480 display. Verify firmware and framework compatibility before installing. Open My Vehicle > BEAMer.
